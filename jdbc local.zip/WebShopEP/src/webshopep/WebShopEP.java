/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package webshopep;

/**
 *
 * @author maxal
 */
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
public class WebShopEP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String usuario ="root";
        String pass ="";
        String url = "jdbc:mysql://localhost:3308/tienda";
        Connection conexion;
        Statement statement;
        ResultSet rs;   
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(WebShopEP.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            conexion = DriverManager.getConnection(url,usuario,pass);
            statement = conexion.createStatement();
            statement.executeUpdate("insert into productos(nombre,precio,cantidad)VALUES ('Gel','18.500','50')");
            rs = statement.executeQuery ("SELECT * FROM PRODUCTOS");
            rs.next();
            do{System.out.println(rs.getInt("id")+" : " + rs.getNString("nombre"));
             } while (rs.next());
            
            
            
        } catch (SQLException ex) {
            Logger.getLogger(WebShopEP.class.getName()).log(Level.SEVERE, null, ex);
        }
        }
        
}
